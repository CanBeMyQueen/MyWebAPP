(function(){
	var img = ["img/auto1.jpg","img/auto2.jpg","img/auto3.jpg"];
		oUl = $(".shuffling_figure").find("ul"),
		autoTimer = null,
		nub = 0;
	autoImg();
	function autoImg(){
		var w = css($(oUl).find("img")[0],"width");
		window.onresize = function(){
			w = css($(oUl).find("img")[0],"width");
		};
		clearInterval(autoTimer);
		autoTimer = setInterval(function(){
			$(oUl).find("img")[0].src = img[nub];
			$(oUl).css("left","0px");
			nub++;
			if(nub>=img.length)nub = 0;
			$(".shuffling_figure_navs").find("span").removeClass("active").eq(nub).addClass("active");
			$(oUl).find("img")[1].src = img[nub];
			$(oUl).animate({"left":-w+"px"});
		},5000);
	}
	$(oUl).on("mouseover",function (){ clearInterval(autoTimer);
	}).on("mouseout",function(){ autoImg(); });

})();



function css(el,attr,val) {
	if(arguments.length < 3){
		var val  = 0;
		if(el.currentStyle) {
			val = el.currentStyle[attr];
		} else {
			val = getComputedStyle(el)[attr];
		}
		if(attr == "opacity") {
			val*=100;
		}
		return parseFloat(val);
	}
	if(attr == "opacity") {
		el.style.opacity = val/100;
		el.style.filter = "alpha(opacity = "+val+")";
	} else {
		el.style[attr] = val + "px";
	}
}
function Tween(el,target,time,type,callBack) {
	clearInterval(el.timer);
	var t = 0;
	var b = {}; 
	var c = {}; 	
	var d = time/20; 
	for(var s in target) {
		b[s] = css(el,s);  
		c[s] = target[s] - b[s];
	}
	el.timer = setInterval(function(){
		t++;
		if(t>d) {
			clearInterval(el.timer);
			callBack&&callBack();	
		} else {
			for(var s in target) {
				var val = Tweens[type](t,b[s],c[s],d);
				css(el,s,val);
			}
		}
	},20);
}
var Tweens = {
	linear: function (t, b, c, d){
		return c*t/d + b;
	},
	easeIn: function(t, b, c, d){
		return c*(t/=d)*t + b;
	}
};